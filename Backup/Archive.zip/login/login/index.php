<?
	$title = "Login";
	$active = "login";
	$static = "../../static";
	include $static.'/functions/index.php';
  include $static.'-only/functions/index.php';
  include $static.'/imports/index/header.php';
	if (isset($_POST["email"])) {
		$email   = $_POST["email"];
	}
	if (isset($_POST["password"])) {
		$password   = $_POST["password"];
	}
	if(checkEmail($active, $email)) {
		echo "errorcheckEmail";
	}
	elseif(checkPassword($active, $password)) {
		echo "errorcheckPassword";
	}
	elseif(login($active, $static, $email, $password)){
		echo "errorlogin";
	}
include $static.'/imports/index/footer.php';
?>

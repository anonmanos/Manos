<link href="style.css" rel="stylesheet" type="text/css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<form name="form1" method="post" action="indexcheck.php">
  <table width="450" border="0" align="center" cellpadding="0" cellspacing="1" 
  	class="square">
    <tr>
      <th colspan="2" scope="row">@@ member @@</th>
    </tr>
    <tr>
      <th width="108" scope="row">username</th>
      <td width="333"><input type="text" name="username" id="username"></td>
    </tr>
    <tr>
      <th scope="row">password</th>
      <td><input type="password" name="password" id="password"></td>
    </tr>
    <tr>
      <th colspan="2" scope="row"><a href="regisform.php">register</a></th>
    </tr>
    <tr>
      <th colspan="2" scope="row">
      <input type="submit" name="button" id="button" value="Submit">
      </th>
    </tr>
  </table>
</form>

<?
  session_start();
  $title  = "Signup";
  $active = "signup";
  $static = "../static";
  include $static.'/functions/index.php';
  include $static.'/imports/index/header.php';
?>
    <div class="page-header">
      <h3>Sign up</h3></div>
        <form id="signup-form" method="post" action="/signup/signup/" class="form-horizontal">
          <input type="hidden" name="_csrf" value="Dqgq0FyHipkdZx8gjoddVPdAiAiR8Xy8Y/WrA=">
          <div class="form-group">
            <label for="name" class="col-sm-3 control-label">Name</label>
            <div class="col-sm-7">
              <input type="text" name="name" id="name" placeholder="Name" autofocus class="form-control">
            </div>
          </div>
          <div class="form-group">
            <label for="email" class="col-sm-3 control-label">Email</label>
            <div class="col-sm-7">
              <input type="email" name="email" id="email" placeholder="Email" autofocus class="form-control">
            </div>
          </div>
          <div class="form-group">
            <label for="password" class="col-sm-3 control-label">Password</label>
            <div class="col-sm-7">
              <input type="password" name="password" id="password" placeholder="Password" class="form-control">
            </div>
          </div>
          <div class="form-group">
            <label for="confirmPassword" class="col-sm-3 control-label">Confirm Password</label>
            <div class="col-sm-7">
              <input type="password" name="confirmPassword" id="confirmPassword" placeholder="Confirm Password" class="form-control">
            </div>
          </div>
          <div class="form-group">
            <div class="col-sm-offset-3 col-sm-7">
              <button type="submit" class="btn btn-success"><i class="fa fa-user-plus"></i>Signup</button>
            </div>
          </div>
        </form>
      </div>
<?
include $static.'/imports/index/footer.php';
?>

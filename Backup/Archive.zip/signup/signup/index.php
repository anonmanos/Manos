<?
  $title  = "Signup";
  $active = "signup";
  $static = "../../static";
  include $static.'/functions/index.php';
  include $static.'-only/functions/index.php';
  include $static.'/imports/index/header.php';
  if (isset($_POST["name"])) { $name   = $_POST["name"];}
  if (isset($_POST["email"])) { $email   = $_POST["email"];}
  if (isset($_POST["password"])) { $password   = $_POST["password"];}
  if (isset($_POST["confirmPassword"])) { $confirmPassword   = $_POST["confirmPassword"];}

  if(checkName($active, $name)){
  }
  elseif(checkEmail($active, $email)){
  }
  elseif(alreadyEmail($active, $static, $email)){
  }
  elseif(checkPassword($active, $password)){
  }
  elseif(matchPassword($active, $password, $confirmPassword)){
  }
  elseif(signup($active, $static, $name, $email, $password, $confirmPassword)){
  }else {
    echo "error function signup";
  }
?>

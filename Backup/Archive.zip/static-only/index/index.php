<?
session_start();
if(empty($_SESSION["gtnsession"])){
  header('Refresh: 0; url=/');
	exit();
}else {

}
?>

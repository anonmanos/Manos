<?
$active = "account";
$static = "../../static";
include $static.'/functions/index.php';
include $static.'-only/index/index.php';
include $static.'-only/functions/index.php';
$title  = $_SESSION['gtnsessionname'];
include $static.'/imports/index/header.php';
if (isset($_POST["name"])) { $name   = $_POST["name"];}
if (isset($_POST["email"])) { $email   = $_POST["email"];}
if (isset($_POST["location"])) { $location   = $_POST["location"];}
if (isset($_POST["website"])) { $website   = $_POST["website"];}
?>
        <?
        if (checkName($active, $name)) {
          echo "error checkName";
        }elseif (checkEmail($active ,$email)) {
          echo "error checkEmail";
        }else {
          profileUpdate($active, $static, $name, $email, $location ,$website);
        }
include $static.'/imports/index/footer.php';
?>

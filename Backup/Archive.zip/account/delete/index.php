<?
  $active = "delete";
  $static = "../../static";
  include $static.'/functions/index.php';
  include $static.'-only/index/index.php';
  include $static.'-only/functions/index.php';
  $title  = $_SESSION['gtnsessionname'];
  include $static.'/imports/index/header.php';
  if (isset($_POST["_csrf"])) { $deleteUser   = $_POST["_csrf"];}
  if(isset($_csrf)||isset($_SESSION['gtnsession'])) {
    include $static.'-only/data/index.php';
    $sql = "delete from users where user_id = '{$_SESSION['gtnsession']}'";
    mysql_query($sql) or die("error=$sql");
    echo '<div class="alert alert-info" role="alert"><h3>Your account has been deleted.<br/><h4>Please! Wait...</h4>
          </div>';
    header('Refresh: 3; url=/');
    session_destroy();
    exit();
  }
	include $static.'/imports/index/footer.php';
?>

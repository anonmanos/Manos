<?
$active = "account";
$static = "../../static";
include $static.'/functions/index.php';
include $static.'-only/index/index.php';
include $static.'-only/functions/index.php';
$title  = $_SESSION['gtnsessionname'];
include $static.'/imports/index/header.php';
if (isset($_POST["currentPassword"])) { $currentPassword   = $_POST["currentPassword"];}
if (isset($_POST["newPassword"])) { $newPassword   = $_POST["newPassword"];}
if (isset($_POST["confirmPassword"])) { $confirmPassword   = $_POST["confirmPassword"];}
$gtnemail = $_SESSION['gtnsessionemail'];
?>
      <div class="container">
        <?
        if (changePassword($active, $static, $currentPassword, $newPassword, $confirmPassword)){
          echo "error changePassword";
        }
        ?>
      </div>

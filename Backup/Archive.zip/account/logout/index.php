<?
	$active = "logout";
	$static = "../../static";
	include $static.'/functions/index.php';
  include $static.'-only/index/index.php';
  include $static.'-only/functions/index.php';
  $title  = $_SESSION['gtnsessionname'];
  include $static.'/imports/index/header.php';
	include $static.'/imports/index/footer.php';
	session_destroy();
	echo '<div class="container">
					<div class="alert alert-info" role="alert">
						<h3>Global Testing Network</h3>
						<h4>Thank you for joining!</h4>
				</div>';
	header('Refresh: 3; url=/');
	exit();
?>

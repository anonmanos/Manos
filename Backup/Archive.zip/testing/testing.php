<?
//$2y$10gGMQ==tTMQ==nNTVE9PQ===

$password = 'kokokok';
echo base64_encode($password);

?>

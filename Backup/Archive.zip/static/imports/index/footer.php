  </div>
  <footer>
  <div class="container text-center">
    <p class="pull-left">© <?=date("Y");?> Global Testing Network. All Rights Reserved</p>
    <ul class="pull-right list-inline">
      <li><a href="https://github.com/sahat/hackathon-starter">GitHub Project</a></li>
      <li><a href="https://github.com/sahat/hackathon-starter/issues">Issues</a></li>
    </ul>
  </div>
  </footer>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?=$static?>/js/bootstrap.min.js"></script>
  </body>
</html>

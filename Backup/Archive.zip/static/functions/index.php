<?


function activeHome($active) {
  if (isset($active)) {
    if($active=='home') {
      echo ' class="active"';
    }
  }
}
function activeAbout($active) {
  if (isset($active)) {
    if($active=='about') {
      echo ' class="active"';
    }
  }
}
function activeContact($active) {
  if (isset($active)) {
    if($active=='contact') {
      echo ' class="active"';
    }
  }
}
function activeSignup($active) {
  if (isset($active)) {
    if($active=='signup') {
      echo ' class="active"';
    }
  }
}
function activeLogin($active) {
  if (isset($active)) {
    if($active=='login') {
      echo ' class="active"';
    }
  }
}
function navbarRight() {
  if(empty($_SESSION["gtnsessionname"])){
    ?>
          <ul class="nav navbar-nav navbar-right">
            <li><a href="/login">Sign in</a></li>
            <li><a href="/signup">Create Account</a></li>
          </ul>
<?
  }else {
?>
          <ul class="nav navbar-nav navbar-right">
            <li class="dropdown">
              <a href="account" data-toggle="dropdown" class="dropdown-toggle">
                <img src="https://graph.facebook.com/10201273959326710/picture?type=large"><?=$_SESSION['gtnsessionname']?>
                <i class="caret"></i>
              </a>
              <ul class="dropdown-menu">
                <li><a href="/account">My Account</a></li>
                <li class="divider"></li>
                <li><a href="/account/logout">Logout</a></li>
              </ul>
            </li>
          </ul>
<?
  }
}
?>

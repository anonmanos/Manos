<?
	$title = "Contact";
  $active = "account";
  $static = "../static";
  include $static.'/functions/index.php';
  include $static.'-only/index/index.php';
  include $static.'-only/functions/index.php';
  include $static.'/imports/index/header.php';
	if (isset($_POST["name"])) {
		$email   = $_POST["email"];
	}
	if (isset($_POST["password"])) {
		$password   = $_POST["password"];
	}
  include $static.'/imports/index/header.php';
?>

<?
  session_start();
  $active = "home";
  $static = "static";
  include $static.'/functions/index.php';
  $title  = "Global Testing Network";
  include $static.'/imports/index/header.php';



  include $static.'/imports/index/footer.php';
?>
